plugins {
    alias(libs.plugins.android.application)  // Android application plugin
    alias(libs.plugins.jetbrains.kotlin.android)  // Kotlin plugin for Android
}

android {
    namespace = "com.example.todo1"
    compileSdk = 34  // Compile against Android API level 34

    defaultConfig {
        applicationId = "com.example.todo1"
        minSdk = 23  // Minimum supported Android version (for vibration API, etc.)
        targetSdk = 33  // Target Android version
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"  // For instrumentation tests
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8  // Set Java compatibility
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"  // Set JVM compatibility
    }
}

dependencies {
    // AndroidX Core Libraries
    implementation("androidx.core:core-ktx:1.9.0")  // Core Kotlin extensions
    implementation("androidx.appcompat:appcompat:1.6.1")  // AppCompat for backward compatibility
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")  // Constraint layout for UI

    // Activity KTX (Kotlin extensions for Android activities)
    implementation("androidx.activity:activity-ktx:1.7.2")

    // Google Material Design Components (for UI elements like buttons, text fields, etc.)
    implementation("com.google.android.material:material:1.7.0")

    // Lifecycle ViewModel (for managing UI-related data in a lifecycle-conscious way)
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.0")

    // RecyclerView (for displaying lists and grids of data in a scrollable layout)
    implementation("androidx.recyclerview:recyclerview:1.3.0")

    // Unit Testing Dependencies
    testImplementation("junit:junit:4.13.2")  // JUnit for unit testing

    // Android Instrumentation Testing Dependencies
    androidTestImplementation("androidx.test.ext:junit:1.1.5")  // JUnit for Android
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")  // Espresso for UI testing
}
