package com.example.todo1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class TaskDetailActivity : AppCompatActivity() {

    private lateinit var taskEditText: EditText
    private var taskIndex: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_detail)

        taskEditText = findViewById(R.id.task_edit_text)

        // Retrieve task and taskIndex from the intent
        val task = intent.getStringExtra("task")
        taskIndex = intent.getIntExtra("taskIndex", -1)

        // Set the task content in the EditText
        taskEditText.setText(task)

        val saveButton: Button = findViewById(R.id.save_button)
        saveButton.setOnClickListener {
            val updatedTask = taskEditText.text.toString()
            val resultIntent = Intent().apply {
                putExtra("task", updatedTask)
                putExtra("taskIndex", taskIndex)
            }
            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }
}
