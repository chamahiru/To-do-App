package com.example.todo1

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class SetReminderActivity : AppCompatActivity() {

    private lateinit var reminderMessage: EditText
    private lateinit var datePickerButton: Button
    private lateinit var timePickerButton: Button
    private lateinit var setReminderButton: Button

    private var reminderDate: String = ""
    private var reminderTime: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_reminder)

        // Initialize Views
        reminderMessage = findViewById(R.id.reminder_message)
        datePickerButton = findViewById(R.id.date_picker_button)
        timePickerButton = findViewById(R.id.time_picker_button)
        setReminderButton = findViewById(R.id.set_reminder_button)

        // Date Picker Dialog
        datePickerButton.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
                reminderDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                datePickerButton.text = reminderDate
            }, year, month, day)

            datePickerDialog.show()
        }

        // Time Picker Dialog
        timePickerButton.setOnClickListener {
            val calendar = Calendar.getInstance()
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val timePickerDialog = TimePickerDialog(this, { _, selectedHour, selectedMinute ->
                reminderTime = String.format("%02d:%02d", selectedHour, selectedMinute)
                timePickerButton.text = reminderTime
            }, hour, minute, true)

            timePickerDialog.show()
        }

        // Set Reminder Button
        setReminderButton.setOnClickListener {
            val message = reminderMessage.text.toString()

            if (message.isNotEmpty() && reminderDate.isNotEmpty() && reminderTime.isNotEmpty()) {
                saveReminder(message, reminderDate, reminderTime)
                Toast.makeText(this, "Reminder set!", Toast.LENGTH_SHORT).show()
                finish() // Close activity after saving reminder
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Function to save reminder data in SharedPreferences
    private fun saveReminder(message: String, date: String, time: String) {
        val sharedPreferences = getSharedPreferences("ReminderPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        editor.putString("reminder_message", message)
        editor.putString("reminder_date", date)
        editor.putString("reminder_time", time)
        editor.apply() // Save the changes
    }
}
