package com.example.todo1

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Vibrator
import android.widget.Button
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.TimeUnit

class TimerActivity : AppCompatActivity() {

    private lateinit var timePicker: TimePicker
    private lateinit var timerTextView: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var resetButton: Button
    private lateinit var setTimerButton: Button
    private lateinit var setReminderButton: Button

    private var timer: CountDownTimer? = null
    private var timeInMillis: Long = 0
    private var isRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer)

        // Initialize Views
        timePicker = findViewById(R.id.time_picker)
        timerTextView = findViewById(R.id.timer_text_view)
        startButton = findViewById(R.id.start_button)
        stopButton = findViewById(R.id.stop_button)
        resetButton = findViewById(R.id.reset_button)
        setTimerButton = findViewById(R.id.set_timer_button)
        setReminderButton = findViewById(R.id.set_reminder_button)

        // Set TimePicker to 24-hour mode
        timePicker.setIs24HourView(true)

        // Set Timer Button
        setTimerButton.setOnClickListener {
            val hours = timePicker.hour
            val minutes = timePicker.minute
            timeInMillis = TimeUnit.HOURS.toMillis(hours.toLong()) + TimeUnit.MINUTES.toMillis(minutes.toLong())

            if (timeInMillis > 0) {
                updateTimerText(timeInMillis)
            } else {
                Toast.makeText(this, "Please set a valid time", Toast.LENGTH_SHORT).show()
            }
        }

        // Start Button
        startButton.setOnClickListener {
            if (timeInMillis > 0 && !isRunning) {
                startTimer(timeInMillis)
            } else {
                Toast.makeText(this, "Set a timer first!", Toast.LENGTH_SHORT).show()
            }
        }

        // Stop Button
        stopButton.setOnClickListener {
            stopTimer()
        }

        // Reset Button
        resetButton.setOnClickListener {
            resetTimer()
        }

        // Set Reminder Button - Navigate to SetReminderActivity
        setReminderButton.setOnClickListener {
            val intent = Intent(this, SetReminderActivity::class.java)
            startActivity(intent)
        }
    }

    private fun startTimer(millis: Long) {
        timer = object : CountDownTimer(millis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                updateTimerText(millisUntilFinished)
            }

            override fun onFinish() {
                updateTimerText(0)
                vibratePhone()
                Toast.makeText(this@TimerActivity, "Time's up!", Toast.LENGTH_SHORT).show()
                isRunning = false
            }
        }.start()
        isRunning = true
    }

    private fun stopTimer() {
        timer?.cancel()
        isRunning = false
    }

    private fun resetTimer() {
        stopTimer()
        updateTimerText(0)
        timeInMillis = 0
    }

    private fun updateTimerText(millis: Long) {
        val hours = TimeUnit.MILLISECONDS.toHours(millis)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        val timeFormatted = String.format("%02d:%02d:%02d", hours, minutes, seconds)
        timerTextView.text = timeFormatted
    }

    private fun vibratePhone() {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(500) // Vibrates for 500 milliseconds
    }
}

