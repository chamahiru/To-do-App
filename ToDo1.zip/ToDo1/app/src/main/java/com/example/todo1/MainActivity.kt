package com.example.todo1

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var tasksAdapter: TasksAdapter
    private lateinit var tasksList: ArrayList<String>
    private val sharedPrefFile = "com.example.todo1.tasks"

    // Registering ActivityResultLauncher for task details
    private lateinit var taskResultLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tasksList = loadTasks()

        val recyclerView: RecyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        tasksAdapter = TasksAdapter(tasksList, this::editTask, this::deleteTask)
        recyclerView.adapter = tasksAdapter

        val addTaskButton: FloatingActionButton = findViewById(R.id.add_task_button)
        addTaskButton.setOnClickListener {
            openTaskDetailActivity(null, -1)
        }

        val timerButton: Button = findViewById(R.id.timer_button)
        timerButton.setOnClickListener {
            startActivity(Intent(this, TimerActivity::class.java))
        }

        // Initialize the ActivityResultLauncher
        taskResultLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                val task = result.data?.getStringExtra("task") ?: return@registerForActivityResult
                val taskIndex = result.data?.getIntExtra("taskIndex", -1) ?: -1

                if (taskIndex != -1) {
                    // Update an existing task
                    tasksList[taskIndex] = task
                    tasksAdapter.notifyItemChanged(taskIndex)
                } else {
                    // Add a new task
                    tasksList.add(task)
                    tasksAdapter.notifyItemInserted(tasksList.size - 1)
                }
                saveTasks()
            }
        }
    }

    private fun openTaskDetailActivity(task: String?, index: Int) {
        val intent = Intent(this, TaskDetailActivity::class.java).apply {
            putExtra("task", task)
            putExtra("taskIndex", index)
        }
        taskResultLauncher.launch(intent)
    }

    private fun editTask(task: String) {
        val index = tasksList.indexOf(task)
        openTaskDetailActivity(task, index)
    }

    private fun deleteTask(task: String) {
        val index = tasksList.indexOf(task)
        if (index != -1) {
            tasksList.removeAt(index)
            tasksAdapter.notifyItemRemoved(index)
            saveTasks()
        } else {
            Toast.makeText(this, "Task not found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveTasks() {
        val sharedPreferences = getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putStringSet("tasks", tasksList.toSet())
        editor.apply()
    }

    private fun loadTasks(): ArrayList<String> {
        val sharedPreferences = getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)
        val tasks = sharedPreferences.getStringSet("tasks", setOf())?.toMutableList() ?: mutableListOf()
        return ArrayList(tasks)
    }
}
